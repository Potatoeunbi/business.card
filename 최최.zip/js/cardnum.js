var searchInput = document.getElementById("search");


var isActiveSearch = () => {
  var searchValue = searchInput.value;

  if (searchValue==8) {
	
	var number = searchInput.value;
	}
};

 searchInput.addEventListener("input", isActiveSearch);